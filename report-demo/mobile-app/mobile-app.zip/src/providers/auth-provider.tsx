import React, { createContext, useContext, useEffect, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
import { useAppSettings } from '@/providers/settings-provider';
import { request } from '@/lib/api';
import { initMqtt, disconnectMqtt } from '@/lib/mqtt';

type AuthContextType = {
  token: string | null;
  deviceId: string | null;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string, confirmPassword: string) => Promise<void>;
  logout: () => Promise<void>;
  isLoggedIn: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(null);
  const [deviceId, setDeviceId] = useState<string | null>(null);
  const { effectiveBaseUrl } = useAppSettings();
  const isLoggedIn = !!token && !!deviceId;

  // Tải token/deviceId từ SecureStore khi mở app
  useEffect(() => {
    (async () => {
      const storedToken = await SecureStore.getItemAsync('authToken');
      const storedDeviceId = await SecureStore.getItemAsync('authDeviceId');
      if (storedToken && storedDeviceId) {
        setToken(storedToken);
        setDeviceId(storedDeviceId);
        // Khôi phục kết nối MQTT khi đã có phiên
        initMqtt(storedToken, storedDeviceId);
      }
    })();
  }, []);

  const login = async (username: string, password: string) => {
    if (!effectiveBaseUrl) throw new Error('Chưa cấu hình URL server. Vui lòng vào Cài đặt.');
    const data = await request<{ token?: string; deviceId?: string }>(
      { apiKey: '' },
      effectiveBaseUrl,
      'api/auth/login',
      {
        method: 'POST',
        body: JSON.stringify({ username, password }),
        headers: { 'Content-Type': 'application/json' },
      },
    );
    const authToken = data.token ?? '';
    const returnedDeviceId = data.deviceId ?? username;
    await SecureStore.setItemAsync('authToken', authToken);
    await SecureStore.setItemAsync('authDeviceId', returnedDeviceId);
    setToken(authToken);
    setDeviceId(returnedDeviceId);
    // Khởi tạo kết nối MQTT ngay sau khi đăng nhập
    initMqtt(authToken, returnedDeviceId);
  };

  const register = async (username: string, password: string, confirmPassword: string) => {
    if (!effectiveBaseUrl) throw new Error('Chưa cấu hình URL server. Vui lòng vào Cài đặt.');
    if (password !== confirmPassword) throw new Error('Mật khẩu xác nhận không khớp.');
    await request(
      { apiKey: '' },
      effectiveBaseUrl,
      'api/auth/register',
      {
        method: 'POST',
        body: JSON.stringify({ username, password, confirmPassword }),
        headers: { 'Content-Type': 'application/json' },
      },
    );
    // Tự động đăng nhập sau khi đăng ký thành công
    await login(username, password);
  };

  const logout = async () => {
    // Ngắt kết nối MQTT
    disconnectMqtt();
    await SecureStore.deleteItemAsync('authToken');
    await SecureStore.deleteItemAsync('authDeviceId');
    setToken(null);
    setDeviceId(null);
  };

  return (
    <AuthContext.Provider value={{ token, deviceId, login, register, logout, isLoggedIn }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth phải dùng trong AuthProvider');
  return ctx;
};
