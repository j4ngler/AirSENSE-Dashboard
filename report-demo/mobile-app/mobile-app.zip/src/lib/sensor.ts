import { ADC_LABELS } from '@/constants/airsense';
import type { SensorDoc } from '@/lib/types';

function readNumber(raw: unknown): number | null {
  if (typeof raw === 'number' && Number.isFinite(raw)) return raw;
  if (typeof raw === 'string') {
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

export function readNamedSensor(content: Record<string, unknown> | null | undefined, name: string): number | null {
  if (!content) return null;
  const direct = readNumber(content[name]);
  if (direct !== null) return direct;
  const lowered = name.toLowerCase();
  for (const key of Object.keys(content)) {
    if (key.toLowerCase() === lowered) {
      return readNumber(content[key]);
    }
  }
  return null;
}

export function adcArray(doc: SensorDoc | null | undefined): number[] {
  const content = doc?.content;
  if (!content) return [];
  const raw = content.adc;
  if (!Array.isArray(raw)) return [];
  return raw.map((value) => readNumber(value)).filter((value): value is number => value !== null);
}

export function readAdcValue(doc: SensorDoc | null | undefined, index: number, label?: string): number | null {
  const content = doc?.content;
  if (!content) return null;
  if (label) {
    const named = readNamedSensor(content, label);
    if (named !== null) return named;
  }
  const values = adcArray(doc);
  if (typeof values[index] === 'number') return values[index];
  const direct = readNumber(content[`ADC${index}`]);
  if (direct !== null) return direct;
  return readNumber(content[`adc${index}`]);
}

export function readTemperature(doc: SensorDoc | null | undefined): number | null {
  return readNamedSensor(doc?.content ?? null, 'Temperature') ?? readNamedSensor(doc?.content ?? null, 'temperature');
}

export function readHumidity(doc: SensorDoc | null | undefined): number | null {
  return readNamedSensor(doc?.content ?? null, 'Humidity') ?? readNamedSensor(doc?.content ?? null, 'humidity');
}

export function sensorTimestamp(doc: SensorDoc | null | undefined): Date | null {
  if (!doc) return null;
  if (typeof doc.time === 'number') return new Date(doc.time * 1000);
  const fallback = doc.createdAt ?? doc.updatedAt;
  if (!fallback) return null;
  const parsed = new Date(fallback);
  return Number.isNaN(parsed.valueOf()) ? null : parsed;
}

export function summarizeAdc(doc: SensorDoc | null | undefined): string {
  if (!doc) return '--';
  const values = ADC_LABELS.map((label, index) => readAdcValue(doc, index, label)).filter((value): value is number => value !== null);
  if (!values.length) return '--';
  const min = Math.min(...values);
  const max = Math.max(...values);
  const avg = values.reduce((sum, value) => sum + value, 0) / values.length;
  return `min ${min.toFixed(0)} / avg ${avg.toFixed(0)} / max ${max.toFixed(0)}`;
}

