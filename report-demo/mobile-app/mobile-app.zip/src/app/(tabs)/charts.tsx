import { useQuery } from '@tanstack/react-query';
import { Text } from 'react-native';

import { ADC_COLORS, ADC_LABELS, HUMIDITY_COLOR, TEMP_COLOR } from '@/constants/airsense';
import { LineChart } from '@/components/line-chart';
import { ActionButton, EmptyState, InlineError, LoadingBlock, Page, Section } from '@/components/ui';
import { fetchHistory, userMessageFromError } from '@/lib/api';
import { formatDateTime } from '@/lib/format';
import { readAdcValue, readHumidity, readTemperature, sensorTimestamp } from '@/lib/sensor';
import { useAppSettings } from '@/providers/settings-provider';

export default function ChartsScreen() {
  const { effectiveBaseUrl, isReady, settings } = useAppSettings();
  const selectedDevice = settings.selectedDevice;
  const fromIso = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

  const historyQuery = useQuery({
    enabled: Boolean(effectiveBaseUrl && selectedDevice),
    queryFn: () => fetchHistory(settings, effectiveBaseUrl, selectedDevice, { from: fromIso, limit: 120 }),
    queryKey: ['history-24h', effectiveBaseUrl, settings.apiKey, selectedDevice, fromIso],
    refetchInterval: settings.refreshMs,
  });

  if (!isReady) return <LoadingBlock label="Preparing charts..." />;

  if (!effectiveBaseUrl) {
    return (
      <Page>
        <EmptyState message="Set the server URL in Settings before loading charts." title="Server URL required" />
      </Page>
    );
  }

  if (!selectedDevice) {
    return (
      <Page>
        <EmptyState message="Choose a device on the Dashboard tab first." title="Device required" />
      </Page>
    );
  }

  const points = [...(historyQuery.data ?? [])].reverse();
  const labels = points.map((point) => formatDateTime(sensorTimestamp(point), '--'));
  const tempSeries = points.map((point) => readTemperature(point)).filter((value): value is number => value !== null);
  const humiditySeries = points.map((point) => readHumidity(point)).filter((value): value is number => value !== null);

  return (
    <Page>
      <Section subtitle="History query uses a sliding 24-hour window and up to 120 samples." title="Trend charts">
        <Text style={{ color: '#475569' }}>Device: {selectedDevice}</Text>
        <InlineError message={historyQuery.error ? userMessageFromError(historyQuery.error) : null} />
        <ActionButton label="Refresh now" onPress={() => void historyQuery.refetch()} secondary />
      </Section>

      {historyQuery.isLoading && !historyQuery.data ? <LoadingBlock label="Loading chart history..." /> : null}

      <Section subtitle="Temp and humidity plotted independently for readability." title="Environment">
        {points.length ? (
          <LineChart
            labels={labels}
            scaleEach
            series={[
              { color: TEMP_COLOR, label: 'Temperature', values: tempSeries },
              { color: HUMIDITY_COLOR, label: 'Humidity', values: humiditySeries },
            ]}
          />
        ) : (
          <EmptyState message="No sensor samples were returned for the last 24 hours." title="No history" />
        )}
      </Section>

      <Section subtitle="Eight ADC traces mapped from the same Mongo history payload." title="ADC">
        {points.length ? (
          <LineChart
            labels={labels}
            scaleEach
            series={ADC_LABELS.map((label, index) => ({
              color: ADC_COLORS[index],
              label,
              values: points
                .map((point) => readAdcValue(point, index, label))
                .filter((value): value is number => value !== null),
            }))}
          />
        ) : (
          <EmptyState message="No ADC samples were returned for the last 24 hours." title="No history" />
        )}
      </Section>
    </Page>
  );
}

