import { useQuery } from '@tanstack/react-query';
import { FlatList, StyleSheet, Text, View } from 'react-native';

import { ActionButton, EmptyState, InlineError, LoadingBlock, Page, Section } from '@/components/ui';
import { fetchHistory, userMessageFromError } from '@/lib/api';
import { formatDateTime, formatNumber } from '@/lib/format';
import { readHumidity, readTemperature, sensorTimestamp, summarizeAdc } from '@/lib/sensor';
import { useAppSettings } from '@/providers/settings-provider';

export default function HistoryScreen() {
  const { effectiveBaseUrl, isReady, settings } = useAppSettings();
  const selectedDevice = settings.selectedDevice;

  const historyQuery = useQuery({
    enabled: Boolean(effectiveBaseUrl && selectedDevice),
    queryFn: () => fetchHistory(settings, effectiveBaseUrl, selectedDevice, { limit: 120 }),
    queryKey: ['history-list', effectiveBaseUrl, settings.apiKey, selectedDevice],
    refetchInterval: settings.refreshMs,
  });

  if (!isReady) return <LoadingBlock label="Preparing history..." />;

  if (!effectiveBaseUrl) {
    return (
      <Page>
        <EmptyState message="Set the server URL in Settings before loading history." title="Server URL required" />
      </Page>
    );
  }

  if (!selectedDevice) {
    return (
      <Page>
        <EmptyState message="Choose a device on the Dashboard tab first." title="Device required" />
      </Page>
    );
  }

  return (
    <Page>
      <Section subtitle="Most recent 120 sensor samples from MongoDB." title="History">
        <Text style={styles.deviceText}>Device: {selectedDevice}</Text>
        <InlineError message={historyQuery.error ? userMessageFromError(historyQuery.error) : null} />
        <ActionButton label="Reload" onPress={() => void historyQuery.refetch()} secondary />
      </Section>

      {historyQuery.isLoading && !historyQuery.data ? <LoadingBlock label="Loading history..." /> : null}

      <Section subtitle="Each row summarizes the ADC range to stay readable on mobile." title="Samples">
        {historyQuery.data?.length ? (
          <FlatList
            data={historyQuery.data}
            keyExtractor={(item, index) => `${item.time ?? item.createdAt ?? index}`}
            renderItem={({ item }) => (
              <View style={styles.row}>
                <Text style={[styles.cell, styles.cellWide]}>{formatDateTime(sensorTimestamp(item), '--')}</Text>
                <Text style={styles.cell}>{formatNumber(readTemperature(item), 1)}</Text>
                <Text style={styles.cell}>{formatNumber(readHumidity(item), 1)}</Text>
                <Text style={[styles.cell, styles.cellWide]}>{summarizeAdc(item)}</Text>
              </View>
            )}
            ListHeaderComponent={
              <View style={[styles.row, styles.headerRow]}>
                <Text style={[styles.headerCell, styles.cellWide]}>Time</Text>
                <Text style={styles.headerCell}>Temp</Text>
                <Text style={styles.headerCell}>Hum</Text>
                <Text style={[styles.headerCell, styles.cellWide]}>ADC summary</Text>
              </View>
            }
          />
        ) : (
          <EmptyState message="No samples were returned for this device." title="No history" />
        )}
      </Section>
    </Page>
  );
}

const styles = StyleSheet.create({
  cell: {
    color: '#0f172a',
    flex: 0.7,
    fontSize: 12,
  },
  cellWide: {
    flex: 1.5,
  },
  deviceText: {
    color: '#475569',
  },
  headerCell: {
    color: '#334155',
    flex: 0.7,
    fontSize: 12,
    fontWeight: '700',
  },
  headerRow: {
    backgroundColor: '#e2e8f0',
    borderRadius: 12,
    marginBottom: 8,
  },
  row: {
    borderBottomColor: '#e2e8f0',
    borderBottomWidth: 1,
    flexDirection: 'row',
    gap: 8,
    paddingVertical: 10,
  },
});

