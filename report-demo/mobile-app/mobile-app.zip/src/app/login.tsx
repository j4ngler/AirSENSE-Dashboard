import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/providers/auth-provider';

export default function LoginScreen() {
  const { login } = useAuth();
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [focusedField, setFocusedField] = useState<'username' | 'password' | null>(null);

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      Alert.alert('Thiếu thông tin', 'Vui lòng nhập tên đăng nhập và mật khẩu.');
      return;
    }
    try {
      setLoading(true);
      await login(username.trim(), password);
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : 'Đăng nhập thất bại.';
      Alert.alert('Đăng nhập thất bại', message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.root}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoText}>✦</Text>
          </View>
          <Text style={styles.appName}>AirSENSE</Text>
          <Text style={styles.tagline}>Hệ thống quan trắc chất lượng không khí</Text>
        </View>

        {/* Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Đăng nhập</Text>
          <Text style={styles.cardSubtitle}>Chào mừng bạn quay lại!</Text>

          {/* Username field */}
          <View style={styles.fieldWrap}>
            <Text style={styles.fieldLabel}>Tên đăng nhập</Text>
            <TextInput
              autoCapitalize="none"
              autoCorrect={false}
              onBlur={() => setFocusedField(null)}
              onChangeText={setUsername}
              onFocus={() => setFocusedField('username')}
              placeholder="Nhập tên đăng nhập"
              placeholderTextColor="#a78bfa"
              style={[
                styles.input,
                focusedField === 'username' && styles.inputFocused,
              ]}
              value={username}
            />
          </View>

          {/* Password field */}
          <View style={styles.fieldWrap}>
            <Text style={styles.fieldLabel}>Mật khẩu</Text>
            <TextInput
              autoCapitalize="none"
              onBlur={() => setFocusedField(null)}
              onChangeText={setPassword}
              onFocus={() => setFocusedField('password')}
              onSubmitEditing={handleLogin}
              placeholder="Nhập mật khẩu"
              placeholderTextColor="#a78bfa"
              returnKeyType="done"
              secureTextEntry
              style={[
                styles.input,
                focusedField === 'password' && styles.inputFocused,
              ]}
              value={password}
            />
          </View>

          {/* Login button */}
          <Pressable
            disabled={loading}
            onPress={handleLogin}
            style={({ pressed }) => [
              styles.primaryButton,
              loading && styles.buttonDisabled,
              pressed && !loading && styles.buttonPressed,
            ]}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.primaryButtonText}>Đăng nhập</Text>
            )}
          </Pressable>

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>hoặc</Text>
            <View style={styles.dividerLine} />
          </View>

          {/* Go to Register */}
          <Pressable
            onPress={() => router.push('/register')}
            style={({ pressed }) => [
              styles.secondaryButton,
              pressed && styles.buttonPressed,
            ]}
          >
            <Text style={styles.secondaryButtonText}>Tạo tài khoản mới</Text>
          </Pressable>
        </View>

        <Text style={styles.footer}>AirSENSE Vietnam © 2025</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const PURPLE = '#4e54c8';
const PURPLE_LIGHT = '#8f94fb';
const PURPLE_DARK = '#312e81';

const styles = StyleSheet.create({
  appName: {
    color: '#fff',
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: 3,
    marginTop: 16,
  },
  buttonDisabled: {
    opacity: 0.55,
  },
  buttonPressed: {
    opacity: 0.75,
    transform: [{ scale: 0.98 }],
  },
  card: {
    backgroundColor: 'rgba(255,255,255,0.97)',
    borderRadius: 28,
    elevation: 12,
    gap: 16,
    marginHorizontal: 4,
    padding: 24,
    shadowColor: '#312e81',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
  },
  cardSubtitle: {
    color: '#64748b',
    fontSize: 14,
    marginBottom: 4,
    marginTop: -6,
  },
  cardTitle: {
    color: PURPLE_DARK,
    fontSize: 24,
    fontWeight: '800',
  },
  divider: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 10,
  },
  dividerLine: {
    backgroundColor: '#e2e8f0',
    flex: 1,
    height: 1,
  },
  dividerText: {
    color: '#94a3b8',
    fontSize: 12,
    fontWeight: '600',
  },
  fieldLabel: {
    color: PURPLE_DARK,
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
  },
  fieldWrap: {
    gap: 4,
  },
  footer: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 12,
    marginTop: 24,
    textAlign: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
    paddingTop: 24,
  },
  input: {
    backgroundColor: '#f5f3ff',
    borderColor: '#c4b5fd',
    borderRadius: 14,
    borderWidth: 1.5,
    color: '#1e1b4b',
    fontSize: 15,
    paddingHorizontal: 16,
    paddingVertical: 13,
  },
  inputFocused: {
    borderColor: PURPLE,
    shadowColor: PURPLE,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  logoCircle: {
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderColor: 'rgba(255,255,255,0.4)',
    borderRadius: 40,
    borderWidth: 2,
    height: 80,
    justifyContent: 'center',
    width: 80,
  },
  logoText: {
    color: '#fff',
    fontSize: 36,
  },
  primaryButton: {
    alignItems: 'center',
    backgroundColor: PURPLE,
    borderRadius: 16,
    marginTop: 4,
    paddingVertical: 15,
    shadowColor: PURPLE_DARK,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  primaryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  root: {
    backgroundColor: PURPLE,
    flex: 1,
  },
  scroll: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  secondaryButton: {
    alignItems: 'center',
    backgroundColor: '#f5f3ff',
    borderColor: '#c4b5fd',
    borderRadius: 16,
    borderWidth: 1.5,
    paddingVertical: 13,
  },
  secondaryButtonText: {
    color: PURPLE,
    fontSize: 15,
    fontWeight: '700',
  },
  tagline: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 13,
    marginTop: 6,
    textAlign: 'center',
  },
});
