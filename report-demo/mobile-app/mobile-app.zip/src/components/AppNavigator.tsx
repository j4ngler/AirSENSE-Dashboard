/**
 * AppNavigator – component điều hướng chính.
 * Đặt ở đây để có thể dùng useAuth() và useAppSettings()
 * đã được bọc bởi providers trong _layout.tsx.
 */
import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Stack } from 'expo-router';
import { useAuth } from '@/providers/auth-provider';
import { useAppSettings } from '@/providers/settings-provider';

export function AppNavigator() {
  const { isReady } = useAppSettings();
  const { isLoggedIn } = useAuth();

  // Hiển thị loading spinner khi đang tải settings
  if (!isReady) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#4e54c8' }}>
        <ActivityIndicator size="large" color="#fff" />
      </View>
    );
  }

  if (!isLoggedIn) {
    // Chưa đăng nhập → hiển thị màn hình auth
    return (
      <Stack screenOptions={{ headerShown: false, animation: 'fade' }}>
        <Stack.Screen name="login" />
        <Stack.Screen name="register" />
      </Stack>
    );
  }

  // Đã đăng nhập → vào màn hình chính
  return (
    <Stack screenOptions={{ headerShown: false, animation: 'fade' }}>
      <Stack.Screen name="(tabs)" />
    </Stack>
  );
}
